<?php  
session_start();  

// Jika sudah login, langsung ke dashboard  
if (isset($_SESSION['username'])) {  
    header("Location: dashboard/index.php");  
    exit;  
}  

// Pesan multi bahasa  
$massage = [  
    'no-token' => [  
        'id' => 'Token tidak ditemukan, silahkan login kembali',  
        'ru' => 'Токен не найден, пожалуйста, войдите снова',  
        'en' => 'Token not found, please login again',  
        'th' => 'ไม่พบโทเค็นโปรดเข้าสู่ระบบอีกครั้ง',  
        'cn' => '找不到令牌，请重新登录',  
    ]  
];  

// Ambil bahasa dari URL  
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';  

// Terjemahan teks  
$translations = [  
    'title' => [  
        'id' => 'Login akPanel',  
        'ru' => 'Вход в akPanel',  
        'en' => 'Login akPanel',  
        'th' => 'เข้าสู่ระบบ akPanel',  
        'cn' => '登录 akPanel',  
    ],  
    'username' => [  
        'id' => 'USERNAME',  
        'ru' => 'ИМЯ ПОЛЬЗОВАТЕЛЯ',  
        'en' => 'USERNAME',  
        'th' => 'ชื่อผู้ใช้',  
        'cn' => '用户名称',  
    ],  
    'password' => [  
        'id' => 'PASSWORD',  
        'ru' => 'ПАРОЛЬ',  
        'en' => 'PASSWORD',  
        'th' => 'รหัสผ่าน',  
        'cn' => '密码',  
    ],  
    'login_button' => [  
        'id' => 'Masuk',  
        'ru' => 'Войти',  
        'en' => 'Login',  
        'th' => 'เข้าสู่ระบบ',  
        'cn' => '登录',  
    ],  
    'login_error' => [  
        'id' => 'Username atau password salah',  
        'ru' => 'Неправильное имя пользователя или пароль',  
        'en' => 'Incorrect username or password',  
        'th' => 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง',  
        'cn' => '用户名或密码错误',  
    ],  
];  

// Fungsi ambil terjemahan dengan fallback ke English  
function t($key, $lang, $translations) {  
    if (isset($translations[$key][$lang])) {  
        return $translations[$key][$lang];  
    }  
    return $translations[$key]['en'];  
}  

// Load data user dari src/user.json  
$userFile = __DIR__ . '/src/user.json';  
$users = [];  
if (file_exists($userFile)) {  
    $users = json_decode(file_get_contents($userFile), true);  
    if (!is_array($users)) {  
        $users = [];  
    }  
}  

$loginError = '';  

// Proses form login POST  
if ($_SERVER['REQUEST_METHOD'] === 'POST') {  
    $username = trim($_POST['un'] ?? '');  
    $password = trim($_POST['pw'] ?? '');  

    $found = false;  
    foreach ($users as $user) {  
        if (($user['username'] ?? '') === $username && ($user['password'] ?? '') === $password) {  
            $found = true;  
            break;  
        }  
    }  

    if ($found) {  
        $_SESSION['username'] = $username;  
        $_SESSION['lang'] = $lang;  
        header("Location: dashboard/index.php");  
        exit;  
    } else {  
        $loginError = t('login_error', $lang, $translations);  
    }  
}  
?>  
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($lang); ?>" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars(t('title', $lang, $translations)); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0a0a0a;
            --surface: rgba(23, 23, 23, 0.85);
            --primary: #7c3aed;
            --text: #e0e0e0;
            --border: rgba(255,255,255,0.1);
            --error: #ef4444;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            background-image: radial-gradient(circle at 50% 50%, rgba(124, 58, 237, 0.1), transparent 60%);
        }

        .login-glass {
            background: var(--surface);
            backdrop-filter: blur(16px);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 2.5rem;
            width: 400px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            transition: all 0.3s ease;
        }

        .login-glass:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0,0,0,0.4);
        }

        h1 {
            text-align: center;
            margin: 0 0 2rem 0;
            font-size: 1.8rem;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #a1a1aa;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 0.8rem;
            background: rgba(0,0,0,0.3);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.2);
        }

        .submit-btn {
            width: 100%;
            padding: 1rem;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-top: 1rem;
        }

        .submit-btn:hover {
            background: #6d28d9;
            transform: translateY(-1px);
        }

        .language-selector {
            position: absolute;
            top: 2rem;
            right: 2rem;
        }

        #language-select {
            appearance: none;
            background: rgba(0,0,0,0.3);
            color: var(--text);
            border: 1px solid var(--border);
            padding: 0.6rem 2rem 0.6rem 1rem;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        #language-select:hover {
            border-color: var(--primary);
        }

        .language-selector::after {
            content: "▼";
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            font-size: 0.6rem;
            pointer-events: none;
            color: var(--text);
        }

        .error-message {
            background: rgba(239, 68, 68, 0.15);
            color: #fca5a5;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid var(--error);
            display: flex;
            gap: 0.8rem;
            align-items: center;
        }

        @media (max-width: 480px) {
            .login-glass {
                width: 90%;
                padding: 1.5rem;
                margin: 1rem;
            }
            
            .language-selector {
                top: 1rem;
                right: 1rem;
            }
        }
    </style>
</head>
<body>
    

    <div class="login-glass">
        <form action="?lang=<?php echo htmlspecialchars($lang); ?>" method="post" autocomplete="off">
            <h1>🔒 <?php echo htmlspecialchars(t('title', $lang, $translations)); ?></h1>
            
            <?php if ($loginError): ?>
                <div class="error-message">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12" y2="16"></line>
                    </svg>
                    <?php echo htmlspecialchars($loginError); ?>
                </div>
            <?php endif; ?>

            <div class="form-group">
                <label for="username"><?php echo htmlspecialchars(t('username', $lang, $translations)); ?></label>
                <input type="text" id="username" name="un" required autofocus placeholder="Enter your username">
            </div>

            <div class="form-group">
                <label for="password"><?php echo htmlspecialchars(t('password', $lang, $translations)); ?></label>
                <input type="password" id="password" name="pw" required placeholder="••••••••">
            </div>

            <button type="submit" class="submit-btn">
                <?php echo htmlspecialchars(t('login_button', $lang, $translations)); ?>
            </button>
        </form>
    </div>
</body>
</html>