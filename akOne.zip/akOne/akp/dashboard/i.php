<?php  
session_start();  

error_reporting(E_ALL);  
ini_set('display_errors', 1);  

if (!isset($_SESSION['username'])) {  
    die("User tidak login");  
}  

$username = $_SESSION['username'];  
$baseDir = realpath("home/");  

if (!$baseDir || !is_dir($baseDir)) {  
    die("Folder user tidak ditemuka atau tidak valid: $baseDir");  
}  

$dirParam = $_GET['dir'] ?? '';  
$dirParam = str_replace(['..', './', '\\'], '', $dirParam);  
$currentPath = realpath($baseDir . DIRECTORY_SEPARATOR . $dirParam);  
if ($currentPath === false || strpos($currentPath, $baseDir) !== 0) {  
    $currentPath = $baseDir;  
}  

$items = scandir($currentPath);  
echo 'Base Dir: ' . $baseDir . '<br>';  
echo 'Current Path: ' . $currentPath . '<br>';  
echo '<pre>';  
print_r($items);  
echo '</pre>';  