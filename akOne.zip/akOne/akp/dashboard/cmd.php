<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Authentication Check
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit;
}

$username = $_SESSION['username'];
$workingDir = realpath("./home/{$username}");

// Initialize Session Directory
if (!isset($_SESSION['current_dir'])) {
    $_SESSION['current_dir'] = $workingDir;
}

// Security Headers
header("Content-Security-Policy: default-src 'self'");
header("X-Content-Type-Options: nosniff");

// Command Execution Function
function executeCommand($command) {
    global $workingDir;
    $currentDir = $_SESSION['current_dir'];
    
    // Validate Current Directory
    if (strpos(realpath($currentDir), realpath($workingDir)) !== 0) {
        $_SESSION['current_dir'] = $workingDir;
        $currentDir = $workingDir;
    }

    $args = preg_split('/\s+/', trim($command), -1, PREG_SPLIT_NO_EMPTY);
    $cmd = strtolower(array_shift($args) ?? '');
    $output = '';

    try {
        switch ($cmd) {
            case 'cd':
                $target = $args[0] ?? '';
                $newDir = realpath($currentDir . '/' . $target);
                
                if ($target === '..') {
                    $newDir = dirname($currentDir);
                } elseif (empty($target)) {
                    $newDir = $workingDir;
                }

                if ($newDir && is_dir($newDir)) {
                    if (strpos($newDir, realpath($workingDir)) === 0) {
                        $_SESSION['current_dir'] = $newDir;
                        $output = htmlspecialchars($newDir) . PHP_EOL;
                    } else {
                        $output = "Access Denied" . PHP_EOL;
                    }
                } else {
                    $output = "Directory not found" . PHP_EOL;
                }
                break;

            case 'dir':
            case 'ls':
                $items = scandir($currentDir);
                $output .= "Contents of " . htmlspecialchars($currentDir) . PHP_EOL;
                foreach ($items as $item) {
                    if ($item === '.' || $item === '..') continue;
                    $path = $currentDir . '/' . $item;
                    $output .= sprintf("%-20s %-10s %s\n",
                        date("Y-m-d H:i", filemtime($path)),
                        is_dir($path) ? "<DIR>" : filesize($path),
                        htmlspecialchars($item)
                    );
                }
                break;

            case 'type':
            case 'cat':
                $file = implode(' ', $args);
                $filePath = realpath($currentDir . '/' . $file);
                if ($filePath && is_file($filePath)) {
                    if (strpos($filePath, realpath($workingDir)) === 0) {
                        $content = file_get_contents($filePath);
                        $output = htmlspecialchars($content) . PHP_EOL;
                    } else {
                        $output = "Access Denied" . PHP_EOL;
                    }
                } else {
                    $output = "File not found" . PHP_EOL;
                }
                break;

            case 'mkdir':
                $dir = implode(' ', $args);
                $newDir = $currentDir . '/' . $dir;
                if (!file_exists($newDir)) {
                    mkdir($newDir, 0755, true);
                    $output = "Directory created" . PHP_EOL;
                } else {
                    $output = "Directory exists" . PHP_EOL;
                }
                break;

            case 'rmdir':
                $dir = implode(' ', $args);
                $target = realpath($currentDir . '/' . $dir);
                if ($target && is_dir($target)) {
                    if (count(scandir($target)) === 2) {
                        rmdir($target);
                        $output = "Directory removed" . PHP_EOL;
                    } else {
                        $output = "Directory not empty" . PHP_EOL;
                    }
                } else {
                    $output = "Directory not found" . PHP_EOL;
                }
                break;

            case 'del':
            case 'rm':
                $file = implode(' ', $args);
                $filePath = realpath($currentDir . '/' . $file);
                if ($filePath && is_file($filePath)) {
                    if (strpos($filePath, realpath($workingDir)) === 0) {
                        unlink($filePath);
                        $output = "File deleted" . PHP_EOL;
                    } else {
                        $output = "Access Denied" . PHP_EOL;
                    }
                } else {
                    $output = "File not found" . PHP_EOL;
                }
                break;

            case 'run':
                $allowedPath = realpath($workingDir . '/.system/child-proses');
                $exe = array_shift($args);
                $exePath = realpath($allowedPath . '/' . $exe);

                if ($exePath && is_file($exePath)) {
                    if (strpos($exePath, $allowedPath) === 0) {
                        $descriptors = [
                            0 => ['pipe', 'r'],
                            1 => ['pipe', 'w'],
                            2 => ['pipe', 'w']
                        ];
                        
                        $process = proc_open(
                            escapeshellcmd($exePath) . ' ' . implode(' ', array_map('escapeshellarg', $args)),
                            $descriptors,
                            $pipes,
                            $currentDir,
                            ['PATH' => '/usr/bin:/bin']
                        );
                        
                        if (is_resource($process)) {
                            $stdout = stream_get_contents($pipes[1]);
                            $stderr = stream_get_contents($pipes[2]);
                            fclose($pipes[0]);
                            fclose($pipes[1]);
                            fclose($pipes[2]);
                            proc_close($process);
                            
                            $output = htmlspecialchars($stdout . PHP_EOL . $stderr);
                        }
                    } else {
                        $output = "Invalid program path" . PHP_EOL;
                    }
                } else {
                    $output = "Program not found" . PHP_EOL;
                }
                break;

            case 'clear':
            case 'cls':
                $_SESSION['cmd_output'] = [];
                break;

            case 'exit':
                session_destroy();
                header("Location: ../dashboard.php");
                exit;

            default:
                $output = "Command not recognized" . PHP_EOL;
        }
    } catch (Exception $e) {
        $output = "Error: " . htmlspecialchars($e->getMessage()) . PHP_EOL;
    }

    return $output;
}

// Handle Command Input
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['command'])) {
    $command = trim($_POST['command']);
    
    // Initialize session storage
    $_SESSION['cmd_history'] = $_SESSION['cmd_history'] ?? [];
    $_SESSION['cmd_output'] = $_SESSION['cmd_output'] ?? [];
    
    // Store command
    array_push($_SESSION['cmd_output'], "> " . htmlspecialchars($command));
    
    // Execute and store output
    $result = executeCommand($command);
    if (!empty($result)) {
        array_push($_SESSION['cmd_output'], $result);
    }
}

// Handle Clear Request
if (isset($_GET['clear'])) {
    $_SESSION['cmd_output'] = [];
    header("Location: cmd.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Terminal - <?= htmlspecialchars($username) ?></title>
    <style>
        /* Terminal Styling */
        body { background: #1a1a1a; color: #c0c0c0; font-family: 'Courier New', monospace; margin: 0; }
        #terminal { padding: 20px; height: calc(100vh - 60px); overflow-y: auto; }
        .prompt { color: #00ff00; }
        .output { white-space: pre-wrap; }
        #input { background: transparent; border: none; color: #fff; font: inherit; width: 80%; outline: none; }
    </style>
</head>
<body>
    <div id="terminal">
        <?php foreach ($_SESSION['cmd_output'] ?? [] as $line): ?>
            <div class="output"><?= $line ?></div>
        <?php endforeach; ?>
    </div>
    <form method="post" action="cmd.php" id="cmdForm">
        <span class="prompt"><?= htmlspecialchars(str_replace($workingDir, '~', $_SESSION['current_dir'])) ?>$</span>
        <input type="text" name="command" id="input" autocomplete="off" autofocus>
    </form>

    <script>
        // Auto-scroll and input handling
        const terminal = document.getElementById('terminal');
        terminal.scrollTop = terminal.scrollHeight;
        
        // Command history
        let history = [];
        let historyPos = -1;
        
        document.getElementById('input').addEventListener('keydown', (e) => {
            if (e.key === 'ArrowUp') {
                e.preventDefault();
                if (historyPos < history.length - 1) {
                    historyPos++;
                    e.target.value = history[history.length - 1 - historyPos];
                }
            } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                if (historyPos > 0) {
                    historyPos--;
                    e.target.value = history[history.length - 1 - historyPos];
                }
            } else if (e.key === 'Enter') {
                history = [...(<?= json_encode($_SESSION['cmd_history'] ?? []) ?>), e.target.value];
                historyPos = -1;
            }
        });
    </script>
</body>
</html>