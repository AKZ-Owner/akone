<?php  
session_start();  

error_reporting(E_ALL);  
ini_set('display_errors', 1);  

if (!isset($_SESSION['username'])) {  
    header("Location: ../login.php");  
    exit;  
}  

$username = $_SESSION['username'];  
$baseDir = realpath("home/{$username}");  
if (!$baseDir || !is_dir($baseDir)) {  
    die("Folder user tidak ditemukan atau tidak valid.");  
}  

// Ambil 'dir' dari URL, ganti backslash dengan slash, hapus '..' dan './'  
$dirParam = $_GET['dir'] ?? '';  
$dirParam = str_replace('\\', '/', $dirParam);  
$dirParam = str_replace(['..', './'], '', $dirParam);  

// Bangun full path dengan menyesuaikan directory separator sesuai OS  
$fullPath = $baseDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $dirParam);  
$currentPath = realpath($fullPath);  
// Validasi supaya tidak keluar dari baseDir  
if ($currentPath === false || strpos($currentPath, $baseDir) !== 0) {  
    $currentPath = $baseDir;  
}  

$uploadError = '';  
$mkdirError = '';  
$fileCreateError = '';  
$deleteError = '';  

// Handle upload  
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['uploadfile'])) {  
    if (!empty($_FILES['uploadfile']['name'])) {  
        $targetFile = $currentPath . DIRECTORY_SEPARATOR . basename($_FILES['uploadfile']['name']);  
        if (move_uploaded_file($_FILES['uploadfile']['tmp_name'], $targetFile)) {  
            $relPath = str_replace($baseDir, '', $currentPath);  
            $relPath = str_replace('\\', '/', trim($relPath, '/\\'));  
            header("Location: ?dir=" . urlencode($relPath));  
            exit;  
        } else {  
            $uploadError = 'Gagal mengupload file.';  
        }  
    } else {  
        $uploadError = 'Tidak ada file yang dipilih.';  
    }  
}  

// Handle buat folder baru  
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['newdir'])) {  
    $newDirName = trim($_POST['newdir']);  
    $newDirName = str_replace(['..', '/', '\\'], '', $newDirName);  
    if ($newDirName === '') {  
        $mkdirError = 'Nama folder tidak boleh kosong.';  
    } else {  
        $newDirPath = $currentPath . DIRECTORY_SEPARATOR . $newDirName;  
        if (file_exists($newDirPath)) {  
            $mkdirError = 'Folder sudah ada.';  
        } else {  
            if (mkdir($newDirPath)) {  
                $relPath = str_replace($baseDir, '', $currentPath);  
                $relPath = str_replace('\\', '/', trim($relPath, '/\\'));  
                header("Location: ?dir=" . urlencode($relPath));  
                exit;  
            } else {  
                $mkdirError = 'Gagal membuat folder baru.';  
            }  
        }  
    }  
}  

// Handle buat file baru  
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['createfile'])) {  
    $newFileName = trim($_POST['newfile']);  
    $newFileName = str_replace(['..', '/', '\\'], '', $newFileName);  
    if ($newFileName === '') {  
        $fileCreateError = 'Nama file tidak boleh kosong.';  
    } else {  
        $newFilePath = $currentPath . DIRECTORY_SEPARATOR . $newFileName;  
        if (file_exists($newFilePath)) {  
            $fileCreateError = 'File sudah ada.';  
        } else {  
            if (file_put_contents($newFilePath, '') !== false) {  
                $relFile = str_replace($baseDir, '', $newFilePath);  
                $relFile = str_replace('\\', '/', trim($relFile, '/\\'));  
                header("Location: edit.php?file=" . urlencode($relFile));  
                exit;  
            } else {  
                $fileCreateError = 'Gagal membuat file baru.';  
            }  
        }  
    }  
}  

// Handle hapus file/folder (lanjutan)  
if (isset($_GET['delete'])) {  
    $targetName = basename($_GET['delete']);  
    $targetPath = realpath($currentPath . DIRECTORY_SEPARATOR . $targetName);  
    if ($targetPath && strpos($targetPath, $baseDir) === 0) {  
        if (is_file($targetPath)) {  
            if (!unlink($targetPath)) {  
                $deleteError = 'Gagal menghapus file.';  
            }  
        } elseif (is_dir($targetPath)) {  
            if (count(scandir($targetPath)) > 2) {  
                $deleteError = 'Folder tidak kosong, hapus isi folder terlebih dahulu.';  
            } else {  
                if (!rmdir($targetPath)) {  
                    $deleteError = 'Gagal menghapus folder.';  
                }  
            }  
        } else {  
            $deleteError = 'Target hapus tidak valid.';  
        }  
    } else {  
        $deleteError = 'Target hapus tidak ditemukan atau tidak diperbolehkan.';  
    }  
    if ($deleteError === '') {  
        $relPath = str_replace($baseDir, '', $currentPath);  
        $relPath = str_replace('\\', '/', trim($relPath, '/\\'));  
        header("Location: ?dir=" . urlencode($relPath));  
        exit;  
    }  
}  

// Fungsi menampilkan ukuran file dalam format readable  
function humanFileSize($size)  
{  
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];  
    for ($i = 0; $size >= 1024 && $i < count($units)-1; $i++) $size /= 1024;  
    return round($size, 2) . ' ' . $units[$i];  
}  

// Baca isi folder  
$items = scandir($currentPath);  

?>  

<!DOCTYPE html>
<html lang="id" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Explorer - <?=htmlspecialchars($username)?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0f0f0f;
            --surface: #1a1a1a;
            --primary: #7c3aed;
            --text: #e0e0e0;
            --border: rgba(255,255,255,0.1);
            --success: #10b981;
            --error: #ef4444;
            --hover: rgba(255,255,255,0.05);
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text);
            padding: 2rem;
            min-height: 100vh;
        }

        .glass-container {
            max-width: 1200px;
            margin: 0 auto;
            background: var(--surface);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            border: 1px solid var(--border);
        }

        h2 {
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            color: var(--text);
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 1rem;
            background: rgba(0,0,0,0.3);
            border-radius: 8px;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }

        .breadcrumb a {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text);
            padding: 0.5rem 1rem;
            border-radius: 6px;
            transition: all 0.2s ease;
            text-decoration: none;
        }

        .breadcrumb a:hover {
            background: var(--hover);
        }

        .file-table {
            width: 100%;
            border-collapse: collapse;
            margin: 2rem 0;
            background: rgba(0,0,0,0.2);
            border-radius: 12px;
            overflow: hidden;
        }

        .file-table th,
        .file-table td {
            padding: 1rem;
            text-align: left;
        }

        .file-table th {
            background: var(--primary);
            color: white;
            font-weight: 600;
        }

        .file-table tr {
            border-bottom: 1px solid var(--border);
        }

        .file-table tr:hover {
            background: var(--hover);
        }

        .file-icon {
            width: 24px;
            height: 24px;
            margin-right: 0.8rem;
        }

        .action-links {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .action-links a {
            color: var(--text);
            text-decoration: none;
            padding: 0.5rem;
            border-radius: 6px;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .action-links a:hover {
            background: var(--hover);
            transform: translateY(-1px);
        }

        .form-group {
            margin: 1.5rem 0;
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        input[type="text"],
        input[type="file"] {
            padding: 0.8rem;
            background: rgba(0,0,0,0.3);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            flex: 1;
            min-width: 250px;
        }

        button {
            padding: 0.8rem 1.5rem;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        button:hover {
            background: #6d28d9;
            transform: translateY(-1px);
        }

        .error {
            padding: 1rem;
            background: rgba(239, 68, 68, 0.15);
            color: #fca5a5;
            border-radius: 8px;
            margin: 1rem 0;
            border: 1px solid var(--error);
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        @media (max-width: 768px) {
            body {
                padding: 1rem;
            }
            
            .glass-container {
                padding: 1rem;
            }
            
            .form-group {
                flex-direction: column;
            }
            
            input, button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="glass-container">
        <h2>📂 File Explorer - <?=htmlspecialchars($username)?></h2>

        <!-- Breadcrumb -->
        <nav class="breadcrumb">
            <?php
            $relativePath = str_replace('\\', '/', trim(str_replace($baseDir, '', $currentPath), '/\\'));
            $pathParts = $relativePath === '' ? [] : explode('/', $relativePath);
            $accPath = '';
            echo '<a href="?dir=">🏠 Home</a>';
            foreach ($pathParts as $part) {
                $accPath .= '/' . $part;
                echo '<a href="?dir=' . urlencode(trim($accPath, '/')) . '">' . htmlspecialchars($part) . '</a>';
            }
            ?>
        </nav>

        <!-- Error Messages -->
        <?php if ($uploadError): ?>
            <div class="error">❌ <?=htmlspecialchars($uploadError)?></div>
        <?php endif; ?>
        <?php if ($mkdirError): ?>
            <div class="error">❌ <?=htmlspecialchars($mkdirError)?></div>
        <?php endif; ?>
        <?php if ($fileCreateError): ?>
            <div class="error">❌ <?=htmlspecialchars($fileCreateError)?></div>
        <?php endif; ?>
        <?php if ($deleteError): ?>
            <div class="error">❌ <?=htmlspecialchars($deleteError)?></div>
        <?php endif; ?>

        <!-- File Table -->
        <table class="file-table">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Tipe</th>
                    <th>Ukuran</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($currentPath !== $baseDir): ?>
                    <tr>
                        <td>
                            <a href="?dir=<?=urlencode(dirname($relativePath))?>">
                                📂 ..
                            </a>
                        </td>
                        <td>Folder</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($items as $item):
                    if ($item === '.' || $item === '..') continue;
                    $itemPath = $currentPath . DIRECTORY_SEPARATOR . $item;
                    $relItemPath = str_replace('\\', '/', trim(str_replace($baseDir, '', $itemPath), '/\\'));
                    $isDir = is_dir($itemPath);
                ?>
                    <tr>
                        <td>
                            <?php if ($isDir): ?>
                                <a href="?dir=<?=urlencode($relItemPath)?>">
                                    📁 <?=htmlspecialchars($item)?>
                                </a>
                            <?php else: ?>
                                📄 <?=htmlspecialchars($item)?>
                            <?php endif; ?>
                        </td>
                        <td><?=$isDir ? 'Folder' : 'File'?></td>
                        <td style="font-family: 'Fira Code';"><?=$isDir ? '-' : humanFileSize(filesize($itemPath))?></td>
                        <td>
                            <div class="action-links">
                                <?php if (!$isDir): ?>
                                    <a href="edit.php?file=<?=urlencode($relItemPath)?>" title="Edit">
                                        ✏️ Edit
                                    </a>
                                    <a href="?dir=<?=urlencode($relativePath)?>&delete=<?=urlencode($item)?>" 
                                       onclick="return confirm('Hapus <?=$isDir ? 'folder' : 'file'?> ini?')" 
                                       title="Hapus">
                                        🗑️ Hapus
                                    </a>
                                <?php else: ?>
                                    <a href="?dir=<?=urlencode($relativePath)?>&delete=<?=urlencode($item)?>" 
                                       onclick="return confirm('Hapus folder ini?')" 
                                       title="Hapus">
                                        🗑️ Hapus
                                    </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Action Forms -->
        <div class="form-group">
            <form class="upload-form" method="post" enctype="multipart/form-data">
                <input type="file" name="uploadfile" id="uploadfile" required />
                <button type="submit">📤 Upload File</button>
            </form>

            <form class="newfile-form" method="post">
                <input type="text" name="newfile" placeholder="Nama file baru" required />
                <button type="submit" name="createfile">📝 Buat File</button>
            </form>

            <form class="mkdir-form" method="post">
                <input type="text" name="newdir" placeholder="Nama folder baru" required />
                <button type="submit">📂 Buat Folder</button>
            </form>
            <a href="./"><button>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16 17 21 12 16 7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
                EXIT</button>
            </a>
        </div>
    </div>
</body>
</html>