<?php  
session_start();  
error_reporting(E_ALL);  
ini_set('display_errors', 1);  

// Periksa autentikasi  
if (!isset($_SESSION['username'])) {  
    header("Location: ../login.php");  
    exit;  
}  

$username = $_SESSION['username'];  
$workingDir = realpath("./home/{$username}"); // Direktori user  

// Inisialisasi working directory  
if (!isset($_SESSION['current_dir'])) {  
    $_SESSION['current_dir'] = $workingDir;  
}  

// Function untuk menjalankan perintah yang aman  
function executeCommand($command) {  
    global $workingDir, $username;  
    
    // Parsing perintah dan argumen  
    $args = explode(' ', trim($command));  
    $cmd = strtolower(array_shift($args));  
    
    // Pastikan working directory user berada di bawah workingDir  
    $currentDir = $_SESSION['current_dir'];  
    if (strpos(realpath($currentDir), realpath($workingDir)) !== 0) {  
        $_SESSION['current_dir'] = $workingDir;  
        $currentDir = $workingDir;  
    }  
    
    $output = "";  
    
    // Daftar perintah yang diizinkan  
    switch($cmd) {  
        case 'dir':  
        case 'ls':  
            // Listing file dan folder  
            $items = scandir($currentDir);  
            $output .= " Directory of " . htmlspecialchars($currentDir) . "\n\n";  
            
            $totalSize = 0;  
            $dirCount = 0;  
            $fileCount = 0;  
            
            foreach ($items as $item) {  
                if ($item == '.' || $item == '..') continue;  
                
                $path = $currentDir . DIRECTORY_SEPARATOR . $item;  
                $isDir = is_dir($path);  
                $size = $isDir ? 0 : filesize($path);  
                $lastMod = date("m/d/Y  H:i", filemtime($path));  
                
                if ($isDir) {  
                    $output .= sprintf("%-20s %-15s %s\n", $lastMod, "<DIR>", $item);  
                    $dirCount++;  
                } else {  
                    $output .= sprintf("%-20s %15s %s\n", $lastMod, number_format($size), $item);  
                    $fileCount++;  
                    $totalSize += $size;  
                }  
            }  
            
            $output .= sprintf("\n%15s File(s) %15s bytes\n", $fileCount, number_format($totalSize));  
            $output .= sprintf("%15s Dir(s) %15s bytes free\n", $dirCount, number_format(disk_free_space($currentDir)));  
            break;  
            
        case 'cd':  
            // Change directory  
            $dir = implode(' ', $args);  
            if (empty($dir) || $dir == '.') {  
                $output .= htmlspecialchars($currentDir) . "\n";  
                break;  
            }  
            
            if ($dir == '..') {  
                $newDir = dirname($currentDir);  
                // Validasi agar tidak keluar dari workingDir  
                if (strpos(realpath($newDir), realpath($workingDir)) === 0) {  
                    $_SESSION['current_dir'] = $newDir;  
                    $output .= htmlspecialchars($newDir) . "\n";  
                } else {  
                    $output .= "Access denied.\n";  
                }  
                break;  
            }  
            
            $newDir = realpath($currentDir . DIRECTORY_SEPARATOR . $dir);  
            if ($newDir && is_dir($newDir) && strpos($newDir, realpath($workingDir)) === 0) {  
                $_SESSION['current_dir'] = $newDir;  
                $output .= htmlspecialchars($newDir) . "\n";  
            } else {  
                $output .= "The system cannot find the path specified.\n";  
            }  
            break;  
            
        case 'type':  
        case 'cat':  
            // Display file content  
            $file = implode(' ', $args);  
            if (empty($file)) {  
                $output .= "Usage: type <filename>\n";  
                break;  
            }  

            $filePath = realpath($currentDir . DIRECTORY_SEPARATOR . $file);  
            if ($filePath && is_file($filePath) && strpos($filePath, realpath($workingDir)) === 0) {  
                $content = file_get_contents($filePath);  
                $output .= htmlspecialchars($content) . "\n";  
            } else {  
                $output .= "File not found.\n";  
            }  
            break;  

        case 'mkdir':  
            // Create directory  
            $dirName = implode(' ', $args);  
            if (empty($dirName)) {  
                $output .= "Usage: mkdir <directory_name>\n";  
                break;  
            }  

            $newDirPath = $currentDir . DIRECTORY_SEPARATOR . $dirName;  
            if (!file_exists($newDirPath)) {  
                if (mkdir($newDirPath)) {  
                    $output .= "Directory created successfully.\n";  
                } else {  
                    $output .= "Failed to create directory.\n";  
                }  
            } else {  
                $output .= "A subdirectory or file " . htmlspecialchars($dirName) . " already exists.\n";  
            }  
            break;  

        case 'rmdir':  
            // Remove directory  
            $dirName = implode(' ', $args);  
            if (empty($dirName)) {  
                $output .= "Usage: rmdir <directory_name>\n";  
                break;  
            }  

            $dirPath = realpath($currentDir . DIRECTORY_SEPARATOR . $dirName);  
            if ($dirPath && is_dir($dirPath) && strpos($dirPath, realpath($workingDir)) === 0) {  
                if (count(scandir($dirPath)) <= 2) {  
                    if (rmdir($dirPath)) {  
                        $output .= "Directory removed successfully.\n";  
                    } else {  
                        $output .= "Failed to remove directory.\n";  
                    }  
                } else {  
                    $output .= "The directory is not empty.\n";  
                }  
            } else {  
                $output .= "The system cannot find the path specified.\n";  
            }  
            break;  

        case 'del':  
        case 'rm':  
            // Delete file  
            $fileName = implode(' ', $args);  
            if (empty($fileName)) {  
                $output .= "Usage: del <filename>\n";  
                break;  
            }  

            $filePath = realpath($currentDir . DIRECTORY_SEPARATOR . $fileName);  
            if ($filePath && is_file($filePath) && strpos($filePath, realpath($workingDir)) === 0) {  
                if (unlink($filePath)) {  
                    $output .= "File deleted successfully.\n";  
                } else {  
                    $output .= "Failed to delete file.\n";  
                }  
            } else {  
                $output .= "Could Not Find " . htmlspecialchars($fileName) . "\n";  
            }  
            break;  

        case 'echo':  
            // Echo text  
            $text = implode(' ', $args);  
            $output .= htmlspecialchars($text) . "\n";  
            break;  

        case 'clear':  
        case 'cls':  
            // Clear screen  
            $_SESSION['cmd_output'] = [];  
            $output = "";  
            break;  

        case 'help':  
            // Show help  
            $output .= "For more information on a specific command, type HELP command-name\n";  
            $output .= "CD       Displays the name of or changes the current directory.\n";  
            $output .= "DIR      Displays a list of files and subdirectories in a directory.\n";  
            $output .= "DEL      Deletes one or more files.\n";  
            $output .= "MKDIR    Creates a directory.\n";  
            $output .= "RMDIR    Removes a directory.\n";  
            $output .= "TYPE     Displays the contents of a text file.\n";  
            $output .= "ECHO     Displays messages, or turns command echoing on or off.\n";  
            $output .= "CLS      Clears the screen.\n";  
            $output .= "HELP     Provides Help information for commands.\n";  
            break;  

        case 'exit':  
            // Exit terminal  
            session_destroy();  
            header("Location: ../dashboard.php");  
            exit;  
            break;  

        default:  
            if (!empty($cmd)) {  
                $output .= "'" . htmlspecialchars($cmd) . "' is not recognized as an internal or external command,\noperable program or batch file.\n";  
            }  
    }  

    return $output;  
}  

// Handle command input  
if (isset($_POST['command'])) {  
    $command = trim($_POST['command']);  
    
    // Initialize command history if not exists  
    if (!isset($_SESSION['cmd_history'])) {  
        $_SESSION['cmd_history'] = [];  
    }  
    
    // Initialize command output if not exists  
    if (!isset($_SESSION['cmd_output'])) {  
        $_SESSION['cmd_output'] = [];  
    }  
    
    // Save command to history  
    array_push($_SESSION['cmd_history'], $command);  
    
    // Execute command and get output  
    $output = executeCommand($command);  
    
    // Save command and output to session  
    array_push($_SESSION['cmd_output'], "> " . $command);  
    if (!empty($output)) {  
        array_push($_SESSION['cmd_output'], $output);  
    }  
}  

// Handle clear command from URL  
if (isset($_GET['clear'])) {  
    $_SESSION['cmd_output'] = [];  
    header("Location: cmd.php");  
    exit;  
}  
?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <title>CMD Browser - <?=htmlspecialchars($username)?></title>  
    <style>  
        body {  
            background-color: #000;  
            color: #CCC;  
            font-family: 'Consolas', 'Courier New', monospace;  
            margin: 0;  
            padding: 0;  
            height: 100vh;  
            display: flex;  
            flex-direction: column;  
        }  
        
        #terminal {  
            background-color: #000;  
            padding: 10px;  
            flex-grow: 1;  
            overflow-y: auto;  
            white-space: pre-wrap;  
            line-height: 1.3;  
        }  
        
        #prompt {  
            display: flex;  
            padding: 10px;  
            background-color: #000;  
            border-top: 1px solid #333;  
        }  
        
        #prompt-text {  
            color: #0F0;  
            margin-right: 5px;  
        }  
        
        #command-input {  
            background-color: transparent;  
            border: none;  
            color: #FFF;  
            font-family: 'Consolas', 'Courier New', monospace;  
            font-size: 16px;  
            width: 100%;  
            outline: none;  
            caret-color: #0F0;  
        }  
        
        .prompt-line {  
            color: #0F0;  
        }  
        
        .command-line {  
            color: #0F0;  
            margin-bottom: 5px;  
        }  
        
        .output-line {  
            color: #CCC;  
            margin-bottom: 5px;  
        }  
        
        .error-message {  
            color: #F00;  
        }  
        
        .directory {  
            color: #09F;  
        }  
        
        .file {  
            color: #FFF;  
        }  
        
        #header {  
            background-color: #222;  
            color: #FFF;  
            padding: 5px 10px;  
            font-size: 14px;  
            display: flex;  
            justify-content: space-between;  
        }  
        
        #title {  
            font-weight: bold;  
        }  
        
        #controls a {  
            color: #FFF;  
            margin-left: 10px;  
            text-decoration: none;  
        }  
        
        #controls a:hover {  
            text-decoration: underline;  
        }  
    </style>  
</head>  
<body>  
    <div id="header">  
        <div id="title">CMD Browser - <?=htmlspecialchars($username)?></div>  
        <div id="controls">  
            <a href="?clear" title="Clear screen">❌</a>  
            <a href="../dashboard.php" title="Exit">🚪</a>  
        </div>  
    </div>  
    
    <div id="terminal">  
        <?php  
        // Display welcome message on first load  
        if (!isset($_SESSION['cmd_output'])) {  
            $_SESSION['cmd_output'] = [  
                "Microsoft Windows [Version 10.0.19045.3086]",  
                "(c) Microsoft Corporation. All rights reserved.",  
                "",  
                "Type HELP for available commands.",  
                ""  
            ];  
        }  
        
        // Display command history and output  
        foreach ($_SESSION['cmd_output'] as $line) {  
            if (strpos($line, '> ') === 0) {  
                echo '<div class="command-line">' . htmlspecialchars($line) . '</div>';  
            } else {  
                // Apply some basic syntax highlighting  
                $formattedLine = htmlspecialchars($line);  
                $formattedLine = preg_replace('/\b([A-Z]:\\\.*?)\b/', '<span class="directory">$1</span>', $formattedLine);  
                $formattedLine = preg_replace('/\b([0-9,]+)\s+bytes\b/', '<span class="file">$1 bytes</span>', $formattedLine);  
                $formattedLine = preg_replace('/\b([0-9,]+)\s+File$s$\b/', '<span class="file">$1 File(s)</span>', $formattedLine);  
                $formattedLine = preg_replace('/\b<DIR>\b/', '<span class="directory"><DIR></span>', $formattedLine);  
                
                echo '<div class="output-line">' . $formattedLine . '</div>';  
            }  
        }  
        ?>  
    </div>  
    
    <div id="prompt">  
        <span id="prompt-text"><?=htmlspecialchars(str_replace($workingDir, 'C:', $_SESSION['current_dir']))?>><span>  
        <form id="command-form" method="post" action="">  
            <input type="text" name="command" id="command-input" autocomplete="off" autofocus />  
        </form>  
    </div>  

    <script>  
        // Auto scroll to bottom of terminal  
        const terminal = document.getElementById('terminal');  
        terminal.scrollTop = terminal.scrollHeight;  
        
        // Command history navigation  
        const commandInput = document.getElementById('command-input');  
        let historyIndex = -1;  
        let tempCommand = '';  
        
        commandInput.addEventListener('keydown', function(e) {  
            if (e.key === 'ArrowUp') {  
                e.preventDefault();  
                const history = <?=json_encode($_SESSION['cmd_history'] ?? [])?>;  
                
                if (historyIndex === -1) {  
                    tempCommand = commandInput.value;  
                }  
                
                if (historyIndex < history.length - 1) {  
                    historyIndex++;  
                    commandInput.value = history[history.length - 1 - historyIndex];  
                }  
            } else if (e.key === 'ArrowDown') {  
                e.preventDefault();  
                if (historyIndex > -1) {  
                    historyIndex--;  
                    if (historyIndex === -1) {  
                        commandInput.value = tempCommand;  
                    } else {  
                        const history = <?=json_encode($_SESSION['cmd_history'] ?? [])?>;  
                        commandInput.value = history[history.length - 1 - historyIndex];  
                    }  
                }  
            } else if (e.key === 'Enter') {
// Submit form on Enter
document.getElementById('command-form').submit();
}
});

javascript
// Focus input on terminal click  
terminal.addEventListener('click', function() {  
    commandInput.focus();  
});  

// Auto focus input on page load  
commandInput.focus();  
</script> </body> </html>