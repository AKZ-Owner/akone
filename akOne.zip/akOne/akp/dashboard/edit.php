<?php  
session_start();  

// Validasi session username  
if (!isset($_SESSION['username']) || !preg_match('/^[a-zA-Z0-9_]+$/', $_SESSION['username'])) {  
    header("Location: ../login.php");  
    exit;  
}  

$username = $_SESSION['username'];  
$baseDir = realpath("home/{$username}");  

// Validasi base directory  
if (!$baseDir || !is_dir($baseDir) || strpos($baseDir, realpath('home')) !== 0) {  
    die("Folder user tidak valid.");  
}  

// Daftar ekstensi yang diizinkan untuk diedit  
$allowedExtensions = ['txt', 'php', 'html', 'css', 'js', 'json', 'xml', 'md'];  

// Fungsi sanitasi path  
function sanitizePath($path) {  
    $path = str_replace(['\\', '/'], DIRECTORY_SEPARATOR, $path);  
    $path = preg_replace('/[^\w\-\.' . preg_quote(DIRECTORY_SEPARATOR, '/') . ']/', '', $path);  
    while (strpos($path, '..') !== false) {  
        $path = str_replace('..', '', $path);  
    }  
    return trim($path, DIRECTORY_SEPARATOR);  
}  

// Ambil parameter file dengan sanitasi  
$fileParam = isset($_GET['file']) ? sanitizePath($_GET['file']) : '';  
$filePath = realpath($baseDir . DIRECTORY_SEPARATOR . $fileParam);  

// Validasi path file  
if ($filePath === false || strpos($filePath, $baseDir) !== 0 || !is_file($filePath) || filesize($filePath) > 1048576) {  
    die('File tidak valid atau terlalu besar.');  
}  

// Validasi ekstensi file  
$fileExt = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));  
if (!in_array($fileExt, $allowedExtensions)) {  
    die('Jenis file tidak diizinkan untuk diedit.');  
}  

$error = '';  
$success = '';  

// Proses penyimpanan file  
if ($_SERVER['REQUEST_METHOD'] === 'POST') {  
    $content = $_POST['content'] ?? '';  
    $backupContent = file_get_contents($filePath);  
    
    if (file_put_contents($filePath, $content) !== false) {  
        $success = 'File berhasil disimpan.';  
        $logMessage = sprintf(  
            "[%s] %s memodifikasi %s (ukuran: %d -> %d bytes)\n",  
            date('Y-m-d H:i:s'),  
            $username,  
            $filePath,  
            strlen($backupContent),  
            strlen($content)  
        );  
        file_put_contents('edit_log.txt', $logMessage, FILE_APPEND);  
    } else {  
        $error = 'Gagal menyimpan file.';  
    }  
}  

// Baca isi file dengan deteksi encoding  
$fileContent = file_get_contents($filePath);  
if (!mb_check_encoding($fileContent, 'UTF-8')) {  
    $fileContent = mb_convert_encoding($fileContent, 'UTF-8', mb_detect_encoding($fileContent));  
}  
?>  

<!DOCTYPE html>
<html lang="id" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Editor - <?=htmlspecialchars(basename($filePath)), ENT_QUOTES?></title>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;500;600&family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0a0a0a;
            --surface: rgba(23, 23, 23, 0.85);
            --primary: #7c3aed;
            --text: #f5f5f5;
            --border: rgba(255,255,255,0.1);
            --success: #10b981;
            --error: #ef4444;
            --warning: #f59e0b;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            padding: 2rem;
            backdrop-filter: blur(20px);
        }

        .glass-panel {
            background: var(--surface);
            border-radius: 16px;
            border: 1px solid var(--border);
            backdrop-filter: blur(12px);
            padding: 2.5rem;
            margin: 0 auto;
            max-width: 1200px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        }

        .editor-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid var(--border);
        }

        .file-meta {
            display: grid;
            gap: 0.5rem;
            font-size: 0.9em;
            color: #a1a1aa;
        }

        .editor-container {
            position: relative;
            margin: 2rem 0;
            border-radius: 12px;
            overflow: hidden;
        }

        .editor-toolbar {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            background: rgba(0,0,0,0.3);
            border-bottom: 1px solid var(--border);
        }

        #code-editor {
            width: 100%;
            min-height: 70vh;
            padding: 2rem;
            background: rgba(0,0,0,0.2);
            border: none;
            color: var(--text);
            font-family: 'Fira Code', monospace;
            font-size: 14px;
            line-height: 1.8;
            resize: none;
            tab-size: 4;
        }

        #code-editor:focus {
            outline: none;
            box-shadow: inset 0 0 0 2px var(--primary);
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: #6d28d9;
            transform: translateY(-1px);
        }

        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin: 1.5rem 0;
            display: flex;
            gap: 1rem;
            align-items: center;
            border: 1px solid transparent;
        }

        .alert-warning {
            background: rgba(245, 158, 11, 0.15);
            border-color: var(--warning);
            color: #fde047;
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.15);
            border-color: var(--error);
            color: #fca5a5;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.15);
            border-color: var(--success);
            color: #6ee7b7;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            background: rgba(255,255,255,0.05);
            transition: all 0.2s ease;
            text-decoration: none;
            color: var(--text);
            margin-top: 2rem;
        }

        .back-link:hover {
            background: rgba(255,255,255,0.1);
            transform: translateY(-1px);
        }

        @media (max-width: 768px) {
            body {
                padding: 1rem;
            }
            
            .glass-panel {
                padding: 1.5rem;
            }
            
            .editor-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="glass-panel">
        <header class="editor-header">
            <div>
                <h1>📝 <?=htmlspecialchars(basename($filePath)), ENT_QUOTES?></h1>
                <div class="file-meta">
                    <span>📍 <?=htmlspecialchars(str_replace($baseDir, 'home/'.$username, $filePath))?></span>
                    <span>📦 <?=round(filesize($filePath)/1024, 2)?> KB</span>
                    <span>🕒 <?=date('Y-m-d H:i:s', filemtime($filePath))?></span>
                </div>
            </div>
            <div class="editor-toolbar">
                <button type="submit" form="editor-form" class="btn btn-primary">
                    💾 Simpan Perubahan
                </button>
            </div>
            <a href="./">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16 17 21 12 16 7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
                EXIT
            </a>
        </header>

        <?php if (!mb_check_encoding($fileContent, 'UTF-8')): ?>
            <div class="alert alert-warning">
                ⚠️ <span>File menggunakan encoding non-UTF-8 - Beberapa karakter mungkin tidak ditampilkan dengan benar</span>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error">
                ❌ <span><?=htmlspecialchars($error)?></span>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                ✅ <span><?=htmlspecialchars($success)?></span>
            </div>
        <?php endif; ?>

        <form method="post" id="editor-form" class="editor-container">
            <textarea id="code-editor" name="content" spellcheck="false"><?=htmlspecialchars($fileContent)?></textarea>
        </form>

        <a href="file_manager.php?dir=<?=urlencode(dirname(str_replace($baseDir), '', $filePath))?>" class="back-link">
            ← Kembali ke Explorer
        </a>
    </div>
</body>
</html>