<?php  
session_start();  

if (!isset($_SESSION['username'])) {  
    header("Location: ../login.php");  
    exit;  
}  

$username = $_SESSION['username'];  

// Tangani perubahan bahasa lewat GET lalu simpan di session  
if (isset($_GET['lang'])) {  
    $allowedLangs = ['id','en','ru','th','cn'];  
    $lang = in_array($_GET['lang'], $allowedLangs) ? $_GET['lang'] : 'en';  
    $_SESSION['lang'] = $lang;  
} else {  
    $lang = $_SESSION['lang'] ?? 'en';  
}  

// Terjemahan  
$translations = [  
    'welcome' => [  
        'id' => 'Selamat datang',  
        'en' => 'Welcome',  
        'ru' => 'Добро пожаловать',  
        'th' => 'ยินดีต้อนรับ',  
        'cn' => '欢迎',  
    ],  
    'manage_domains' => [  
        'id' => 'Kelola Domain',  
        'en' => 'Manage Domains',  
        'ru' => 'Управление доменами',  
        'th' => 'จัดการโดเมน',  
        'cn' => '管理域名',  
    ],  
    'manage_ftp' => [  
        'id' => 'Kelola FTP',  
        'en' => 'Manage FTP',  
        'ru' => 'Управление FTP',  
        'th' => 'จัดการ FTP',  
        'cn' => '管理FTP',  
    ],  
    'logout' => [  
        'id' => 'Keluar',  
        'en' => 'Logout',  
        'ru' => 'Выйти',  
        'th' => 'ออกจากระบบ',  
        'cn' => '登出',],  
    'select_language' => [  
        'id' => 'Pilih Bahasa',  
        'en' => 'Select Language',  
        'ru' => 'Выбрать язык',  
        'th' => 'เลือกภาษา',  
        'cn' => '选择语言',  
    ],
    'file_manager' => [  
        'id' => 'Pengelola File',  
        'en' => 'File Manager',  
        'ru' => 'Файловый менеджер',  
        'th' => 'ตัวจัดการไฟล์',  
        'cn' => '文件管理器',  
    ]
];  

function t($key, $lang, $tid) {  
    return $tid[$key][$lang] ?? $tid[$key]['en'] ?? $key;  
}  

?>  
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($lang); ?>" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard akPanel</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0f0f0f;
            --surface: rgba(23, 23, 23, 0.85);
            --primary: #7c3aed;
            --text: #e0e0e0;
            --border: rgba(255,255,255,0.1);
            --hover: rgba(255,255,255,0.05);
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text);
            margin: 0;
            min-height: 100vh;
            background-image: radial-gradient(circle at 25% 25%, rgba(124, 58, 237, 0.1), transparent 50%);
        }

        header {
            background: var(--surface);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border);
            backdrop-filter: blur(12px);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-title {
            font-size: 1.3rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        nav {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        nav a {
            color: var(--text);
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        nav a:hover {
            background: var(--hover);
            transform: translateY(-1px);
        }

        .language-selector {
            position: relative;
        }

        #lang-select {
            appearance: none;
            background: rgba(0,0,0,0.3);
            color: var(--text);
            border: 1px solid var(--border);
            padding: 0.5rem 2rem 0.5rem 1rem;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        #lang-select:hover {
            border-color: var(--primary);
        }

        .language-selector::after {
            content: "▼";
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            font-size: 0.6rem;
            pointer-events: none;
            color: var(--text);
        }

        main {
            padding: 2rem;
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2rem;
        }

        .card {
            background: var(--surface);
            border-radius: 16px;
            padding: 2rem;
            border: 1px solid var(--border);
            backdrop-filter: blur(8px);
            transition: all 0.3s ease;
            box-shadow: 0 8px 32px rgba(0,0,0,0.2);
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0,0,0,0.3);
        }

        .card h2 {
            font-size: 1.4rem;
            margin-bottom: 1rem;
            color: var(--text);
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        .card p {
            color: #a1a1aa;
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .card button {
            background: var(--primary);
            color: white;
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card button:hover {
            background: #6d28d9;
            transform: translateY(-1px);
        }

        @media (max-width: 768px) {
            header {
                flex-direction: column;
                gap: 1rem;
                padding: 1rem;
            }
            
            main {
                padding: 1rem;
                grid-template-columns: 1fr;
            }
            
            .card {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-title">
            🚀 akPanel Dashboard
            <span style="font-size: 0.9rem; font-weight: 400; color: #a1a1aa;">
                <?=t('welcome', $lang, $translations)?>, <?=htmlspecialchars($username)?>
            </span>
        </div>
        
        <nav>
            <form method="get" class="language-selector">
                <select name="lang" id="lang-select" onchange="this.form.submit()">
                    <?php
                    $languages = ['id'=>'🇮🇩 Bahasa', 'en'=>'🇬🇧 English', 'ru'=>'🇷🇺 Русский', 'th'=>'🇹🇭 ไทย', 'cn'=>'🇨🇳 中文'];
                    foreach ($languages as $code => $label):
                    ?>
                        <option value="<?=htmlspecialchars($code)?>" <?=($lang === $code) ? 'selected' : ''?>>
                            <?=htmlspecialchars($label)?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
            
            <a href="logout.php" class="logout">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16 17 21 12 16 7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
                <?=t('logout', $lang, $translations)?>
            </a>
        </nav>
    </header>

    <main>
        <section class="card" id="file-manager">
            <h2>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 2h9a2 2 0 0 1 2 2z"></path>
                </svg>
                <?=t('file_manager', $lang, $translations)?>
            </h2>
            <p><?=t('file_manager_desc', $lang, $translations)?></p>
            <a href="./file_manager.php">
                <button>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 15v4c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2v-4M17 8l-5-5-5 5M12 4.2v10.3"/>
                    </svg>
                    <?=t('open', $lang, $translations)?>
                </button>
            </a>
        </section>

        <section class="card" id="domains">
            <h2>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="2" y1="12" x2="22" y2="12"></line>
                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                </svg>
                <?=t('manage_domains', $lang, $translations)?>
            </h2>
            <p><?=t('domains_desc', $lang, $translations)?></p>
            <button onclick="showComingSoon()">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 5v14M5 12h14"/>
                </svg>
                <?=t('add', $lang, $translations)?>
            </button>
        </section>

        <section class="card" id="ftp">
            <h2>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
                <?=t('manage_ftp', $lang, $translations)?>
            </h2>
            <p><?=t('ftp_desc', $lang, $translations)?></p>
            <button onclick="showComingSoon()">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="8.5" cy="7" r="4"></circle>
                    <line x1="20" y1="8" x2="20" y2="14"></line>
                    <line x1="23" y1="11" x2="17" y2="11"></line>
                </svg>
                <?=t('add_account', $lang, $translations)?>
            </button>
        </section>
    </main>

    <script>
        function showComingSoon() {
            alert("<?=t('coming_soon', $lang, $translations)?>");
        }
    </script>
</body>
</html>